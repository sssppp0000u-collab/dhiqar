# DHIQAR TV

تطبيق IPTV عربي يدعم Android Mobile وAndroid TV، مع تحكم كامل بالريموت ومشغل Media3.

## الميزات

- فتح مباشر بدون شاشة تسجيل دخول.
- اتصال Xtream Codes.
- تصنيفات القنوات.
- قائمة القنوات داخل كل تصنيف.
- بحث عن القنوات.
- مفضلة محفوظة محلياً.
- تشغيل HLS داخل التطبيق.
- أزرار D-Pad والـ Enter/Center للريموت.
- أرقام الريموت لاختيار القناة مباشرة.
- Channel Up / Channel Down للتنقل السريع.
- واجهة عربية Landscape.
- Android TV + Mobile.
- GitHub Actions لبناء APK.

## البناء

المشروع يستخدم Android Gradle Plugin 8.7.3 وGradle 8.9.

على GitHub:
1. ارفع المشروع إلى مستودع.
2. افتح تبويب Actions.
3. شغل `Build DHIQAR TV APK`.
4. بعد اكتمال البناء ستجد APK في Artifacts.

على Termux:
```bash
pkg install openjdk-17 -y
# إذا كان openjdk-17 غير متاح في مستودع Termux لديك استخدم JDK مناسباً يدعم Gradle/AGP.
gradle --version
cd DHIQAR-TV
gradle --no-daemon :app:assembleDebug
```

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## إعداد Xtream

بيانات الحساب الحالية موجودة في:
`app/src/main/java/com/dhiqar/tv/XtreamConfig.java`

**مهم:** لا تجعل المستودع عاماً إذا بقيت بيانات Xtream داخل الكود. الأفضل للمستودع العام نقلها إلى GitHub Secrets/BuildConfig قبل النشر.

## ملاحظة قانونية

استخدم التطبيق فقط مع خوادم وحسابات ومحتوى لديك الحق في الوصول إليه.
