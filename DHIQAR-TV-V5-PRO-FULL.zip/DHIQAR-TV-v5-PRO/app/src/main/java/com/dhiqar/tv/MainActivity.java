package com.dhiqar.tv;

import android.app.AlertDialog;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private LinearLayout root, categoryBar, channelList;
    private TextView status;
    private ScrollView channelScroll;
    private XtreamApi api;
    private final List<XtreamApi.Category> categories = new ArrayList<>();
    private final List<XtreamApi.Channel> current = new ArrayList<>();
    private final Set<String> favorites = new LinkedHashSet<>();

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler();
    private SharedPreferences prefs;

    private ExoPlayer player;
    private PlayerView playerView;
    private int currentIndex = -1;
    private int selectedCategory = 0;
    private String numberBuffer = "";
    private Runnable numberRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        prefs = getSharedPreferences("dhiqar_tv", MODE_PRIVATE);
        loadFavorites();
        showSplash();
    }

    private void showSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView logo = text("DHIQAR", 44, Color.rgb(0, 230, 118));
        TextView title = text("ذي قار TV", 42, Color.WHITE);
        TextView sub = text("بث مباشر • سريع • عربي", 18, Color.rgb(174, 184, 190));
        box.addView(logo);
        box.addView(title);
        box.addView(sub);
        f.addView(box, new FrameLayout.LayoutParams(-1, -1));
        setContentView(f);

        f.postDelayed(this::connect, 700);
    }

    private void connect() {
        api = new XtreamApi(XtreamConfig.SERVER, XtreamConfig.USERNAME, XtreamConfig.PASSWORD);
        showLoading("جاري الاتصال بالسيرفر…");

        io.execute(() -> {
            try {
                List<XtreamApi.Category> result = api.categories();
                runOnUiThread(() -> showHome(result));
            } catch (Exception e) {
                runOnUiThread(() -> showConnectionError(e));
            }
        });
    }

    private void showConnectionError(Exception e) {
        new AlertDialog.Builder(this)
                .setTitle("DHIQAR TV")
                .setMessage("تعذر الاتصال بالسيرفر.\nتأكد من الإنترنت أو أن السيرفر متاح.")
                .setPositiveButton("إعادة المحاولة", (d, w) -> connect())
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void showLoading(String message) {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.rgb(7, 9, 11));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView t = text(message, 24, Color.WHITE);
        box.addView(t);
        f.addView(box, new FrameLayout.LayoutParams(-1, -1));
        setContentView(f);
    }

    private void showHome(List<XtreamApi.Category> result) {
        categories.clear();
        categories.add(new XtreamApi.Category("FAV", "⭐ المفضلة"));
        categories.addAll(result);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 18, 28, 16);
        root.setBackgroundColor(Color.rgb(7, 9, 11));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView brand = text("ذي قار TV", 31, Color.rgb(0, 230, 118));
        brand.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(brand, new LinearLayout.LayoutParams(0, 62, 1));

        status = text("جاهز", 16, Color.rgb(174, 184, 190));
        status.setGravity(Gravity.CENTER);
        header.addView(status, new LinearLayout.LayoutParams(190, 62));

        TextView search = text("🔎 بحث", 18, Color.WHITE);
        search.setGravity(Gravity.CENTER);
        search.setFocusable(true);
        search.setClickable(true);
        search.setBackground(panel(false));
        search.setOnFocusChangeListener((v, has) -> v.setBackground(panel(has)));
        search.setOnClickListener(v -> showSearch());
        search.setOnKeyListener((v, key, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN &&
                    (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER)) {
                showSearch();
                return true;
            }
            return false;
        });
        header.addView(search, new LinearLayout.LayoutParams(145, 62));
        root.addView(header);

        categoryBar = new LinearLayout(this);
        categoryBar.setOrientation(LinearLayout.HORIZONTAL);
        categoryBar.setGravity(Gravity.CENTER_VERTICAL);

        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setFillViewport(false);
        categoryScroll.addView(categoryBar);
        root.addView(categoryScroll, new LinearLayout.LayoutParams(-1, 78));

        channelScroll = new ScrollView(this);
        channelScroll.setFillViewport(true);
        channelScroll.setVerticalScrollBarEnabled(false);

        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        channelList.setPadding(0, 4, 0, 10);
        channelScroll.addView(channelList);
        root.addView(channelScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        buildCategories();
        loadCategory(0);
    }

    private void buildCategories() {
        categoryBar.removeAllViews();

        for (int i = 0; i < categories.size(); i++) {
            final int index = i;
            TextView item = text(categories.get(i).name, 17, Color.WHITE);
            item.setGravity(Gravity.CENTER);
            item.setPadding(28, 0, 28, 0);
            item.setFocusable(true);
            item.setClickable(true);
            item.setBackground(panel(i == selectedCategory));

            item.setOnFocusChangeListener((v, has) -> {
                if (has) v.setBackground(panel(true));
                else v.setBackground(panel(index == selectedCategory));
            });

            item.setOnClickListener(v -> loadCategory(index));
            item.setOnKeyListener((v, key, event) -> {
                if (event.getAction() == KeyEvent.ACTION_DOWN &&
                        (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER)) {
                    loadCategory(index);
                    return true;
                }
                return false;
            });

            categoryBar.addView(item, new LinearLayout.LayoutParams(-2, 62));
        }
    }

    private void loadCategory(int index) {
        selectedCategory = index;
        refreshCategoryVisuals();
        channelList.removeAllViews();
        status.setText("جاري التحميل…");

        if (index == 0) {
            current.clear();
            for (String id : favorites) {
                XtreamApi.Channel c = new XtreamApi.Channel();
                c.id = id;
                c.name = prefs.getString("fav_name_" + id, "مفضلة");
                c.logo = prefs.getString("fav_logo_" + id, "");
                c.categoryId = prefs.getString("fav_cat_" + id, "");
                c.streamUrl = prefs.getString("fav_url_" + id, "");
                if (!c.streamUrl.isEmpty()) current.add(c);
            }
            renderChannels();
            return;
        }

        String id = categories.get(index).id;
        io.execute(() -> {
            try {
                List<XtreamApi.Channel> result = api.channels(id);
                runOnUiThread(() -> {
                    current.clear();
                    current.addAll(result);
                    renderChannels();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("خطأ في التحميل");
                    Toast.makeText(this, "تعذر تحميل القنوات", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void refreshCategoryVisuals() {
        if (categoryBar == null) return;
        for (int i = 0; i < categoryBar.getChildCount(); i++) {
            View v = categoryBar.getChildAt(i);
            v.setBackground(panel(i == selectedCategory || v.hasFocus()));
        }
    }

    private void renderChannels() {
        channelList.removeAllViews();
        status.setText(current.size() + " قناة");

        if (current.isEmpty()) {
            TextView empty = text("لا توجد قنوات في هذا التصنيف", 22, Color.rgb(174, 184, 190));
            empty.setGravity(Gravity.CENTER);
            channelList.addView(empty, new LinearLayout.LayoutParams(-1, 120));
            return;
        }

        for (int i = 0; i < current.size(); i++) {
            addChannelRow(current.get(i), i);
        }

        channelList.post(() -> {
            if (channelList.getChildCount() > 0) channelList.getChildAt(0).requestFocus();
        });
    }

    private void addChannelRow(XtreamApi.Channel c, int index) {
        final int n = index;

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(18, 0, 18, 0);
        row.setFocusable(true);
        row.setClickable(true);
        row.setBackground(panel(false));

        TextView num = text(String.format("%03d", index + 1), 19, Color.rgb(0, 217, 255));
        num.setGravity(Gravity.CENTER);
        row.addView(num, new LinearLayout.LayoutParams(76, 72));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = text(c.name, 21, Color.WHITE);
        TextView live = text("● مباشر", 13, Color.rgb(0, 230, 118));
        info.addView(name, new LinearLayout.LayoutParams(-1, 40));
        info.addView(live, new LinearLayout.LayoutParams(-1, 27));
        row.addView(info, new LinearLayout.LayoutParams(0, 86, 1));

        TextView star = text(favorites.contains(c.id) ? "★" : "☆", 29,
                favorites.contains(c.id) ? Color.rgb(0, 230, 118) : Color.LTGRAY);
        star.setGravity(Gravity.CENTER);
        row.addView(star, new LinearLayout.LayoutParams(65, 86));

        row.setOnFocusChangeListener((v, has) -> {
            v.setBackground(panel(has));
            if (has) {
                currentIndex = n;
                status.setText(String.format("%03d  •  %s", n + 1, c.name));
            }
        });

        row.setOnClickListener(v -> playAt(n));

        row.setOnKeyListener((v, key, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;

            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                playAt(n);
                return true;
            }

            if (key == KeyEvent.KEYCODE_FAVORITE || key == KeyEvent.KEYCODE_MENU) {
                toggleFavorite(c);
                star.setText(favorites.contains(c.id) ? "★" : "☆");
                star.setTextColor(favorites.contains(c.id) ? Color.rgb(0, 230, 118) : Color.LTGRAY);
                return true;
            }

            if (key == KeyEvent.KEYCODE_CHANNEL_UP) {
                playAt(Math.min(current.size() - 1, n + 1));
                return true;
            }

            if (key == KeyEvent.KEYCODE_CHANNEL_DOWN) {
                playAt(Math.max(0, n - 1));
                return true;
            }

            if (key >= KeyEvent.KEYCODE_0 && key <= KeyEvent.KEYCODE_9) {
                handleNumber(key - KeyEvent.KEYCODE_0);
                return true;
            }

            if (key == KeyEvent.KEYCODE_INFO) {
                showChannelInfo(c, n);
                return true;
            }

            return false;
        });

        channelList.addView(row, new LinearLayout.LayoutParams(-1, 88));
    }

    private void handleNumber(int digit) {
        numberBuffer += digit;
        status.setText("رقم القناة: " + numberBuffer);

        if (numberRunnable != null) handler.removeCallbacks(numberRunnable);
        numberRunnable = () -> {
            try {
                int number = Integer.parseInt(numberBuffer) - 1;
                numberBuffer = "";
                if (number >= 0 && number < current.size()) playAt(number);
                else status.setText("القناة غير موجودة");
            } catch (Exception ignored) {
                numberBuffer = "";
            }
        };
        handler.postDelayed(numberRunnable, 900);
    }

    private void toggleFavorite(XtreamApi.Channel c) {
        if (favorites.contains(c.id)) {
            favorites.remove(c.id);
            prefs.edit()
                    .remove("fav_name_" + c.id)
                    .remove("fav_logo_" + c.id)
                    .remove("fav_cat_" + c.id)
                    .remove("fav_url_" + c.id)
                    .apply();
            Toast.makeText(this, "أزيلت من المفضلة", Toast.LENGTH_SHORT).show();
        } else {
            favorites.add(c.id);
            prefs.edit()
                    .putString("fav_name_" + c.id, c.name)
                    .putString("fav_logo_" + c.id, c.logo == null ? "" : c.logo)
                    .putString("fav_cat_" + c.id, c.categoryId == null ? "" : c.categoryId)
                    .putString("fav_url_" + c.id, c.streamUrl)
                    .apply();
            Toast.makeText(this, "⭐ أضيفت للمفضلة", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadFavorites() {
        // Favorites are persisted individually; this method intentionally leaves
        // discovery to the stored key set created below.
        for (String key : prefs.getAll().keySet()) {
            if (key.startsWith("fav_name_")) {
                favorites.add(key.substring("fav_name_".length()));
            }
        }
    }

    private void playAt(int index) {
        if (index < 0 || index >= current.size()) return;
        currentIndex = index;
        play(current.get(index));
    }

    private void play(XtreamApi.Channel c) {
        releasePlayer();

        player = new ExoPlayer.Builder(this).build();
        playerView = new PlayerView(this);
        playerView.setPlayer(player);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);

        setContentView(playerView);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                Toast.makeText(MainActivity.this,
                        "تعذر تشغيل القناة", Toast.LENGTH_LONG).show();
            }
        });

        MediaItem item = MediaItem.fromUri(c.streamUrl);
        player.setMediaItem(item);
        player.prepare();
        player.play();
    }

    private void releasePlayer() {
        if (player != null) {
            player.stop();
            player.release();
            player = null;
        }
        playerView = null;
    }

    private void showSearch() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("اكتب اسم القناة");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setTextSize(19);
        input.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("🔎 البحث عن قناة")
                .setView(input)
                .setPositiveButton("بحث", null)
                .setNegativeButton("إلغاء", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String term = input.getText().toString().trim();
                if (term.isEmpty()) return;
                dialog.dismiss();
                search(term);
            });
            input.requestFocus();
            input.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }, 200);
        });

        dialog.show();
    }

    private void search(String term) {
        status.setText("جاري البحث…");
        io.execute(() -> {
            try {
                List<XtreamApi.Channel> result = api.search(term);
                runOnUiThread(() -> {
                    current.clear();
                    current.addAll(result);
                    renderChannels();
                    status.setText(result.size() + " نتيجة بحث");
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "تعذر البحث", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showChannelInfo(XtreamApi.Channel c, int n) {
        new AlertDialog.Builder(this)
                .setTitle(String.format("%03d  %s", n + 1, c.name))
                .setMessage("الحالة: مباشر\nالمعرف: " + c.id)
                .setPositiveButton("تشغيل", (d, w) -> playAt(n))
                .setNeutralButton("المفضلة", (d, w) -> {
                    toggleFavorite(c);
                    renderChannels();
                })
                .setNegativeButton("إغلاق", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        if (player != null) {
            releasePlayer();
            if (!categories.isEmpty()) showHome(new ArrayList<>(categories.subList(1, categories.size())));
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        io.shutdownNow();
        releasePlayer();
        super.onDestroy();
    }

    private TextView text(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private GradientDrawable panel(boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(selected ? Color.rgb(22, 75, 56) : Color.rgb(17, 22, 26));
        g.setCornerRadius(18);
        g.setStroke(selected ? 2 : 1,
                selected ? Color.rgb(0, 230, 118) : Color.rgb(35, 43, 48));
        return g;
    }
}
