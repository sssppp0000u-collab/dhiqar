package com.dhiqar.tv;

import java.util.Locale;

public final class ArabicNames {
    private ArabicNames() {}

    public static String category(String s) {
        String x = s == null ? "" : s.trim();
        String l = x.toLowerCase(Locale.ROOT);
        if (l.contains("iraq") || l.contains("irag")) return "🇮🇶 القنوات العراقية";
        if (l.contains("sport")) return "⚽ الرياضة";
        if (l.contains("news")) return "📰 الأخبار";
        if (l.contains("movie") || l.contains("cinema")) return "🎬 الأفلام";
        if (l.contains("series") || l.contains("serial") || l.contains("drama")) return "📺 المسلسلات";
        if (l.contains("relig") || l.contains("quran") || l.contains("islam")) return "🕌 دينية";
        if (l.contains("kid") || l.contains("children")) return "👶 أطفال";
        if (l.contains("arab")) return "🌍 عربية";
        if (l.contains("entertain")) return "🎭 ترفيه";
        if (l.contains("music")) return "🎵 موسيقى";
        if (l.contains("document")) return "📚 وثائقيات";
        return x;
    }

    public static String channel(String s) {
        String x = s == null ? "" : s.trim();
        String l = x.toLowerCase(Locale.ROOT);
        if (l.equals("al sharqiya") || l.contains("alsharqiya")) return "الشرقية";
        if (l.equals("al iraqiya") || l.contains("iraqiya")) return "العراقية";
        if (l.contains("alsumaria") || l.contains("al sumaria")) return "السومرية";
        if (l.contains("dijlah") || l.contains("dijla")) return "دجلة";
        if (l.contains("alrasheed") || l.contains("al rasheed")) return "الرشيد";
        if (l.contains("alforat") || l.contains("al forat")) return "الفرات";
        if (l.contains("utv")) return "UTV";
        if (l.contains("mbc iraq")) return "MBC العراق";
        if (l.contains("al arabiya")) return "العربية";
        if (l.contains("al hadath")) return "الحدث";
        if (l.contains("al jazeera")) return "الجزيرة";
        return x;
    }
}
