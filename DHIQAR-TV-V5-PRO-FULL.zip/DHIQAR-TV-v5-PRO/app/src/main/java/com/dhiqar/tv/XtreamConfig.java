package com.dhiqar.tv;

public final class XtreamConfig {
    private XtreamConfig() {}

    // User-supplied Xtream account. For a public GitHub repository, move these
    // values to GitHub Secrets / BuildConfig before publishing the repository.
    public static final String SERVER = "http://vod4k.cc:80";
    public static final String USERNAME = "3143771383105485";
    public static final String PASSWORD = "5846751342";
}
