package com.dhiqar.tv;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class XtreamApi {
    public static class Category {
        public final String id;
        public final String name;
        public Category(String id, String name) { this.id = id; this.name = name; }
    }

    public static class Channel {
        public String id, name, logo, categoryId, streamUrl;
    }

    private final String server, user, pass;

    public XtreamApi(String server, String user, String pass) {
        this.server = server.replaceAll("/+$", "");
        this.user = user;
        this.pass = pass;
    }

    private String get(String action) throws Exception {
        String q = server + "/player_api.php?username=" +
                URLEncoder.encode(user, "UTF-8") + "&password=" +
                URLEncoder.encode(pass, "UTF-8");
        if (action != null && !action.isEmpty()) q += "&" + action;

        HttpURLConnection c = (HttpURLConnection) new URL(q).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "DHIQAR-TV/5.0");
        int code = c.getResponseCode();

        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream(),
                StandardCharsets.UTF_8));

        StringBuilder b = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close();
        c.disconnect();

        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code);
        }
        return b.toString();
    }

    public List<Category> categories() throws Exception {
        JSONArray a = new JSONArray(get("action=get_live_categories"));
        List<Category> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String id = o.optString("category_id");
            String name = ArabicNames.category(o.optString("category_name"));
            if (!id.isEmpty()) out.add(new Category(id, name));
        }
        return out;
    }

    public List<Channel> channels(String categoryId) throws Exception {
        String action = "action=get_live_streams&category_id=" +
                URLEncoder.encode(categoryId, "UTF-8");
        return parseChannels(get(action), categoryId);
    }

    public List<Channel> allChannels() throws Exception {
        return parseChannels(get("action=get_live_streams"), "");
    }

    public List<Channel> search(String term) throws Exception {
        String q = term.toLowerCase(Locale.ROOT);
        List<Channel> all = allChannels();
        List<Channel> out = new ArrayList<>();
        for (Channel c : all) {
            if (c.name.toLowerCase(Locale.ROOT).contains(q)) out.add(c);
        }
        return out;
    }

    private List<Channel> parseChannels(String raw, String fallbackCategory) throws Exception {
        JSONArray a = new JSONArray(raw);
        List<Channel> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Channel c = new Channel();
            c.id = o.optString("stream_id");
            c.name = ArabicNames.channel(o.optString("name"));
            c.logo = o.optString("stream_icon");
            c.categoryId = o.optString("category_id", fallbackCategory);
            c.streamUrl = server + "/live/" + enc(user) + "/" + enc(pass) + "/" + enc(c.id) + ".m3u8";
            if (!c.id.isEmpty()) out.add(c);
        }
        return out;
    }

    public String epg(String streamId) throws Exception {
        return get("action=get_short_epg&stream_id=" +
                URLEncoder.encode(streamId, "UTF-8") + "&limit=8");
    }

    private String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (Exception e) { return s; }
    }
}
