DHIQAR TV V4 PRO
================
نسخة مطورة على مشروع V3.1 الأصلي:
- شاشة افتتاحية احترافية متحركة.
- استخدام شعار المستخدم الأصلي كما هو.
- Xtream Codes login.
- تصنيفات وقنوات مباشرة.
- بحث/واجهة قائمة القنوات الموجودة بالمشروع.
- مشغل Media3.
- دعم Android 21+.
- Gradle 8.9 + Android Gradle Plugin 8.7.3 + Kotlin 2.0.21.

مهم للبناء في Termux:
يجب تحديد Android SDK عبر ANDROID_HOME أو local.properties.
