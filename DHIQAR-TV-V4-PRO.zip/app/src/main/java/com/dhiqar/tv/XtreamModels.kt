package com.dhiqar.tv

import com.google.gson.annotations.SerializedName

data class XtreamLoginResponse(
    @SerializedName("user_info") val userInfo: XtreamUserInfo? = null,
    @SerializedName("server_info") val serverInfo: XtreamServerInfo? = null
)

data class XtreamUserInfo(
    @SerializedName("username") val username: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("auth") val auth: Int? = null,
    @SerializedName("exp_date") val expDate: String? = null,
    @SerializedName("active_cons") val activeConnections: String? = null,
    @SerializedName("max_connections") val maxConnections: String? = null,
    @SerializedName("message") val message: String? = null
)

data class XtreamServerInfo(
    @SerializedName("url") val url: String? = null,
    @SerializedName("port") val port: String? = null,
    @SerializedName("timezone") val timezone: String? = null
)

data class XtreamCategory(
    @SerializedName("category_id") val categoryId: String = "",
    @SerializedName("category_name") val categoryName: String = "",
    @SerializedName("parent_id") val parentId: Int? = null
)

data class XtreamChannel(
    @SerializedName("num") val number: Int? = null,
    @SerializedName("name") val name: String = "",
    @SerializedName("stream_id") val streamId: Int = 0,
    @SerializedName("stream_icon") val streamIcon: String? = null,
    @SerializedName("category_id") val categoryId: String? = null,
    @SerializedName("epg_channel_id") val epgChannelId: String? = null
)
