package com.dhiqar.tv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var loginPanel: View
    private lateinit var homePanel: View
    private lateinit var serverInput: EditText
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var loginStatus: TextView
    private lateinit var accountText: TextView
    private lateinit var categoryRecycler: RecyclerView
    private lateinit var channelRecycler: RecyclerView
    private lateinit var loading: ProgressBar
    private lateinit var errorText: TextView

    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var channelAdapter: ChannelAdapter

    private var api: XtreamApi? = null
    private var server = ""
    private var username = ""
    private var password = ""

    private val prefs by lazy {
        getSharedPreferences("dhiqar_tv", MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        bindViews()
        setupRecyclerViews()
        restoreLogin()

        loginButton.setOnClickListener { loginAndLoad() }
    }

    private fun bindViews() {
        loginPanel = findViewById(R.id.loginPanel)
        homePanel = findViewById(R.id.homePanel)
        serverInput = findViewById(R.id.serverInput)
        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        loginStatus = findViewById(R.id.loginStatus)
        accountText = findViewById(R.id.accountText)
        categoryRecycler = findViewById(R.id.categoryRecycler)
        channelRecycler = findViewById(R.id.channelRecycler)
        loading = findViewById(R.id.loading)
        errorText = findViewById(R.id.errorText)
    }

    private fun setupRecyclerViews() {
        categoryAdapter = CategoryAdapter { category ->
            loadChannels(category?.categoryId)
        }
        channelAdapter = ChannelAdapter { openPlayer(it) }

        categoryRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        categoryRecycler.adapter = categoryAdapter
        categoryRecycler.setHasFixedSize(true)

        channelRecycler.layoutManager = GridLayoutManager(this, 3)
        channelRecycler.adapter = channelAdapter
    }

    private fun restoreLogin() {
        serverInput.setText(prefs.getString("server", ""))
        usernameInput.setText(prefs.getString("username", ""))
        passwordInput.setText(prefs.getString("password", ""))

        if (serverInput.text.isNotBlank() && usernameInput.text.isNotBlank() &&
            passwordInput.text.isNotBlank()) {
            loginButton.requestFocus()
        } else {
            serverInput.requestFocus()
        }
    }

    private fun loginAndLoad() {
        server = serverInput.text.toString().trim()
        username = usernameInput.text.toString().trim()
        password = passwordInput.text.toString()

        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            loginStatus.text = "اكتب السيرفر واسم المستخدم وكلمة المرور"
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            try {
                val currentApi = withContext(Dispatchers.IO) { XtreamApi.create(server) }
                api = currentApi

                val response = withContext(Dispatchers.IO) {
                    currentApi.login(username, password)
                }

                val info = response.userInfo
                if (info?.auth != 1) {
                    throw IllegalStateException(
                        info?.message?.takeIf { it.isNotBlank() }
                            ?: "بيانات الدخول غير صحيحة أو الحساب غير فعال"
                    )
                }

                prefs.edit()
                    .putString("server", server)
                    .putString("username", username)
                    .putString("password", password)
                    .apply()

                accountText.text = "الحالة: ${info.status ?: "غير معروف"}   •   الانتهاء: ${info.expDate ?: "غير معروف"}"
                showHome()
                loadCategories()
            } catch (e: Exception) {
                loginStatus.text = "خطأ: ${e.message ?: "تعذر الاتصال بالسيرفر"}"
            } finally {
                setLoading(false)
            }
        }
    }

    private fun loadCategories() {
        val currentApi = api ?: return
        showBusy(true)

        lifecycleScope.launch {
            try {
                val categories = withContext(Dispatchers.IO) {
                    currentApi.getLiveCategories(username, password)
                }
                val list = ArrayList<XtreamCategory?>()
                list.add(null)
                list.addAll(categories)
                categoryAdapter.submitList(list)
                loadChannels(null)
            } catch (e: Exception) {
                showError("تعذر تحميل الأقسام: ${e.message ?: ""}")
            } finally {
                showBusy(false)
            }
        }
    }

    private fun loadChannels(categoryId: String?) {
        val currentApi = api ?: return
        showBusy(true)

        lifecycleScope.launch {
            try {
                val channels = withContext(Dispatchers.IO) {
                    currentApi.getLiveStreams(username, password, categoryId = categoryId)
                }
                channelAdapter.submitList(channels)
                if (channels.isEmpty()) showError("لا توجد قنوات في هذا القسم")
                else errorText.visibility = View.GONE
            } catch (e: Exception) {
                showError("تعذر تحميل القنوات: ${e.message ?: ""}")
            } finally {
                showBusy(false)
            }
        }
    }

    private fun openPlayer(channel: XtreamChannel) {
        if (channel.streamId <= 0) {
            Toast.makeText(this, "معرّف القناة غير صالح", Toast.LENGTH_SHORT).show()
            return
        }

        val base = server.removeSuffix("/")
        val url = "$base/live/$username/$password/${channel.streamId}.m3u8"

        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
                .putExtra(PlayerActivity.EXTRA_URL, url)
        )
    }

    private fun showHome() {
        loginPanel.visibility = View.GONE
        homePanel.visibility = View.VISIBLE
        channelRecycler.requestFocus()
    }

    private fun setLoading(value: Boolean) {
        loginButton.isEnabled = !value
        loginButton.text = if (value) "جاري الاتصال..." else "دخول وتحميل القنوات"
    }

    private fun showBusy(value: Boolean) {
        loading.visibility = if (value) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        errorText.text = message
        errorText.visibility = View.VISIBLE
    }
}
