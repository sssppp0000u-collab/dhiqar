package com.dhiqar.tv

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApi {
    @GET("player_api.php")
    suspend fun playerApi(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String? = null,
        @Query("category_id") categoryId: String? = null
    ): String

    @GET("player_api.php")
    suspend fun login(
        @Query("username") username: String,
        @Query("password") password: String
    ): XtreamLoginResponse

    @GET("player_api.php")
    suspend fun getLiveCategories(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String = "get_live_categories"
    ): List<XtreamCategory>

    @GET("player_api.php")
    suspend fun getLiveStreams(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String = "get_live_streams",
        @Query("category_id") categoryId: String? = null
    ): List<XtreamChannel>

    companion object {
        fun create(server: String): XtreamApi {
            val value = server.trim()
            val withScheme = if (value.startsWith("http://") || value.startsWith("https://")) value else "http://$value"
            val baseUrl = if (withScheme.endsWith("/")) withScheme else "$withScheme/"
            return Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XtreamApi::class.java)
        }
    }
}
