package com.dhiqar.tv

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CategoryAdapter(
    private val onSelected: (XtreamCategory?) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    private val items = mutableListOf<XtreamCategory?>()
    private var selected = 0

    fun submitList(list: List<XtreamCategory?>) {
        items.clear()
        items.addAll(list)
        selected = 0
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, 48.dp(parent.context)
            ).apply { setMargins(5.dp(parent.context), 4.dp(parent.context), 5.dp(parent.context), 4.dp(parent.context)) }
            setPadding(22.dp(parent.context), 0, 22.dp(parent.context), 0)
            gravity = Gravity.CENTER
            textSize = 15f
            isFocusable = true
            isClickable = true
            setTextColor(Color.WHITE)
        }
        return VH(tv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.text.text = item?.categoryName?.ifBlank { "قسم" } ?: "الكل"
        holder.setSelected(position == selected)

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                selected = p
                notifyDataSetChanged()
                onSelected(items[p])
            }
        }

        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            holder.setSelected(position == selected, hasFocus)
            v.animate().scaleX(if (hasFocus) 1.06f else 1f).scaleY(if (hasFocus) 1.06f else 1f).setDuration(110).start()
        }
    }

    override fun getItemCount(): Int = items.size

    class VH(val text: TextView) : RecyclerView.ViewHolder(text) {
        fun setSelected(selected: Boolean, focused: Boolean = false) {
            val d = GradientDrawable()
            d.cornerRadius = 22f
            if (selected || focused) {
                d.setColor(Color.rgb(22, 76, 110))
                d.setStroke(2.dp(text.context), Color.rgb(0, 217, 255))
            } else {
                d.setColor(Color.rgb(14, 25, 39))
                d.setStroke(1.dp(text.context), Color.rgb(42, 62, 82))
            }
            text.background = d
        }
    }
}

private fun Int.dp(context: android.content.Context): Int =
    (this * context.resources.displayMetrics.density).toInt()
