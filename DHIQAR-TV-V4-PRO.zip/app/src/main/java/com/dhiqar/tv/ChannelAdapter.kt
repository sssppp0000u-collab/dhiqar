package com.dhiqar.tv

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(
    private val onSelected: (XtreamChannel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    private val items = mutableListOf<XtreamChannel>()

    fun submitList(list: List<XtreamChannel>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val root = FrameLayout(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 76.dp(context)
            ).apply { setMargins(6.dp(context), 6.dp(context), 6.dp(context), 6.dp(context)) }
            isFocusable = true
            isClickable = true
        }

        val num = TextView(parent.context).apply {
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.rgb(126, 155, 178))
        }
        val title = TextView(parent.context).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textSize = 15f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        root.addView(num, FrameLayout.LayoutParams(52.dp(parent.context), -1))
        root.addView(title, FrameLayout.LayoutParams(-1, -1).apply {
            marginStart = 56.dp(parent.context)
            marginEnd = 12.dp(parent.context)
        })
        return VH(root, num, title)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.number.text = item.number?.toString() ?: item.streamId.toString()
        holder.title.text = item.name.ifBlank { "قناة ${item.streamId}" }
        holder.setFocus(false)

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onSelected(items[p])
        }
        holder.itemView.setOnFocusChangeListener { v, focused ->
            holder.setFocus(focused)
            v.animate().scaleX(if (focused) 1.035f else 1f).scaleY(if (focused) 1.035f else 1f).setDuration(110).start()
        }
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View, val number: TextView, val title: TextView) :
        RecyclerView.ViewHolder(itemView) {
        fun setFocus(focused: Boolean) {
            val d = GradientDrawable()
            d.cornerRadius = 17f
            d.setColor(if (focused) Color.rgb(20, 56, 78) else Color.rgb(13, 24, 37))
            d.setStroke(if (focused) 3 else 1, if (focused) Color.rgb(0, 217, 255) else Color.rgb(36, 57, 77))
            itemView.background = d
        }
    }
}

private fun Int.dp(context: android.content.Context): Int =
    (this * context.resources.displayMetrics.density).toInt()
